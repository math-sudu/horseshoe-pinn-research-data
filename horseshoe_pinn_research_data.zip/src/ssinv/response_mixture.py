"""Bayesian load inference with a common discrete family of physical responses.

Stiffness is integrated by quadrature. Conditional on a stiffness node the
load posterior is Gaussian; its observation likelihood updates the node mass.
Every field uses that node's response, before averaging across stiffness.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.linalg import cho_factor, cho_solve
from scipy.special import logsumexp


@dataclass
class MixturePosterior:
    weights: np.ndarray             # case, stiffness
    component_means: np.ndarray     # case, stiffness, load
    component_covariances: np.ndarray  # stiffness, load, load

    def target_mean(self, target):
        """Evaluate a stiffness-dependent (node, ..., load) physical map."""
        target = np.asarray(target)
        fields = target.reshape(target.shape[0], -1, target.shape[-1])
        weighted = self.weights[..., None] * self.component_means
        result = weighted.reshape(len(weighted), -1) @ fields.transpose(0, 2, 1).reshape(-1, fields.shape[1])
        return result.reshape((len(weighted),) + target.shape[1:-1])

    def target_moments(self, target):
        """Include within-node uncertainty and between-node mean variation."""
        target = np.asarray(target)
        fields = target.reshape(target.shape[0], -1, target.shape[-1])
        component = np.einsum("nkl,kml->nkm", self.component_means, fields)
        mean = np.einsum("nk,nkm->nm", self.weights, component)
        within = np.einsum("kml,klq,kmq->km", fields, self.component_covariances, fields)
        variance = self.weights @ within + np.einsum(
            "nk,nkm->nm", self.weights, (component-mean[:, None, :])**2)
        shape = (len(mean),) + target.shape[1:-1]
        return mean.reshape(shape), variance.reshape(shape)

    def load_moments(self):
        identity = np.broadcast_to(np.eye(self.component_means.shape[-1]),
                                   self.component_covariances.shape)
        return self.target_moments(identity)


class ConditionedResponse:
    def __init__(self, response, rows):
        self.prior_mean = response.prior_mean
        self.log_prior = np.log(response.weights)
        self.maps = response.observations[:, rows]
        r = response.noise_covariance[np.ix_(rows, rows)]
        gains, covariances, factors, log_determinants = [], [], [], []
        for matrix in self.maps:
            cross = response.prior_covariance @ matrix.T
            factor = cho_factor(matrix @ cross + r, lower=True)
            gain = cho_solve(factor, cross.T).T
            covariance = response.prior_covariance-gain @ cross.T
            gains.append(gain)
            covariances.append((covariance+covariance.T)/2)
            factors.append(factor)
            log_determinants.append(2*np.log(np.diag(factor[0])).sum())
        self.gains = np.array(gains)
        self.covariances = np.array(covariances)
        self.factors = factors
        self.log_determinants = np.array(log_determinants)

    def fit(self, readings):
        readings = np.atleast_2d(readings)
        residuals = readings[:, None, :]-self.maps @ self.prior_mean
        means = self.prior_mean + np.einsum("nkr,klr->nkl", residuals, self.gains)
        quadratics = np.column_stack([
            np.einsum("nr,rn->n", residuals[:, k], cho_solve(factor, residuals[:, k].T))
            for k, factor in enumerate(self.factors)])
        log_weights = self.log_prior-.5*(quadratics+self.log_determinants)
        weights = np.exp(log_weights-logsumexp(log_weights, axis=1, keepdims=True))
        return MixturePosterior(weights, means, self.covariances)


class ResponseMixture:
    def __init__(self, observations, weights, prior_mean, prior_std, noise_covariance):
        self.observations = np.asarray(observations, dtype=float)
        self.weights = np.asarray(weights, dtype=float)
        if np.any(self.weights <= 0) or not np.isclose(self.weights.sum(), 1):
            raise ValueError("Stiffness quadrature weights must be positive and sum to one")
        self.prior_mean = np.asarray(prior_mean, dtype=float)
        self.prior_covariance = np.diag(np.square(prior_std))
        self.noise_covariance = np.asarray(noise_covariance, dtype=float)
        n_rows = self.observations.shape[1]
        if self.noise_covariance.shape != (n_rows, n_rows):
            raise ValueError("Noise covariance must cover the raw coordinate rows")

    def condition(self, rows):
        return ConditionedResponse(self, np.asarray(rows, dtype=int))


def target_projection(target):
    """Compress a target while preserving its mean squared physical norm.

    The target is often many contour/depth locations, but a three-anchor,
    four-load response occupies at most twelve field directions. This exact
    linear-algebra compression avoids constructing pointwise covariances for
    each prospective reading. Only floating-point null directions are dropped.
    """
    target = np.asarray(target)
    fields = target.reshape(target.shape[0], -1, target.shape[-1])
    matrix = fields.transpose(1, 0, 2).reshape(fields.shape[1], -1)/np.sqrt(fields.shape[1])
    _, singular, right = np.linalg.svd(matrix, full_matrices=False)
    keep = singular > np.finfo(float).eps*max(matrix.shape)*singular[0]
    return (singular[keep, None]*right[keep]).reshape(-1, fields.shape[0], fields.shape[-1]).transpose(1, 0, 2)


def expected_variance_reduction(baseline, augmented, projection):
    """Per-prior-predictive-draw integrand of expected target variance reduction.

    E Var(p|y0) - E Var(p|y0,yi) = E ||E(p|y0,yi)-E(p|y0)||^2.
    projection includes the physical mean-square quadrature normalization.
    Both posteriors must come from subsets of the same future survey draw.
    """
    change = augmented.target_mean(projection)-baseline.target_mean(projection)
    return np.sum(change**2, axis=1)
