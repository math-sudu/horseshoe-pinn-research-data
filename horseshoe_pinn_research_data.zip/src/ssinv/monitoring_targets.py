"""Physical targets and feasible choices for the common response posterior."""
import numpy as np

from .response_mixture import target_projection
from .section_recovery import thickness_weights


TARGETS = {
    "pressure": "Mean squared contact pressure over the uniform outer-arc grid.",
    "transition_stress": (
        "Mean squared compression-positive tangential stress at the left and right "
        "lower-transition midpoints, with equal section weights and trapezoidal "
        "through-thickness weights divided by support thickness."
    ),
}


def monitoring_projection(fields, depth, target):
    """Return a map whose squared Euclidean norm is the physical target norm."""
    if target == "pressure":
        values = fields["pressure_mpa"]
    elif target == "transition_stress":
        weights = thickness_weights(depth)/(depth[-1]-depth[0])
        values = fields["stress_mpa"][:, 1:3, :, 0]
        values = values*np.sqrt(len(depth)*weights)[None, None, :, None]
    else:
        raise ValueError(f"Unknown monitoring target: {target}")
    return target_projection(values)


def select_candidate(scores, allowed):
    """Maximize within the feasible set; resolve equivalent scores by index."""
    allowed = np.sort(np.asarray(allowed, dtype=int))
    if not len(allowed):
        raise ValueError("No feasible added-reflector location")
    scores = np.asarray(scores)
    best = allowed[np.argmax(scores[allowed])]
    equivalent = allowed[np.isclose(scores[allowed], scores[best], rtol=1e-10, atol=1e-15)]
    return int(equivalent[0]), equivalent
