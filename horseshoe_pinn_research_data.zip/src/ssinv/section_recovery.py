"""Section resultants and exact field changes of a response-mixture posterior."""
from __future__ import annotations

import numpy as np


def thickness_weights(depth):
    """Trapezoidal integration weights on the actual outer-to-inner depths."""
    spacing = np.diff(depth)
    return np.r_[spacing[0], spacing[:-1]+spacing[1:], spacing[-1]]/2


def section_resultants(tangential_response, depth):
    """Integrate (..., depth, load) compression into (..., N/M, load).

    Stress is in MPa and depth in m. N is MN/m of tunnel axis; M is
    MN m/m, positive for compression concentrated toward the intrados.
    These are direct stress integrals, without a beam stress-profile assumption.
    """
    weights = thickness_weights(depth)
    force = np.einsum("d,...dl->...l", weights, tangential_response)
    moment = np.einsum("d,...dl->...l", weights*(depth-(depth[0]+depth[-1])/2),
                       tangential_response)
    return np.stack((force, moment), axis=-2)


def mixture_update_terms(baseline, augmented, target):
    """Split a field-mean change into conditional-load and node-mass terms.

    Midpoint weights give the exact symmetric product difference
    delta(w*a) = mean(w)*delta(a) + delta(w)*mean(a).
    The terms are correlated; their squared norms require the cross term.
    Every stiffness node keeps its own physical target response.
    """
    states = (
        .5*(augmented.weights+baseline.weights)[..., None]
        *(augmented.component_means-baseline.component_means),
        .5*(augmented.weights-baseline.weights)[..., None]
        *(augmented.component_means+baseline.component_means))
    fields = target.reshape(target.shape[0], -1, target.shape[-1])
    matrix = fields.transpose(0, 2, 1).reshape(-1, fields.shape[1])
    shape = (len(baseline.weights),)+target.shape[1:-1]
    return tuple((state.reshape(len(state), -1) @ matrix).reshape(shape)
                 for state in states)
