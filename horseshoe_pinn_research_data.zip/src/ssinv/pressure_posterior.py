"""Load-space inference on a physics-trained mixed neural response."""
from __future__ import annotations

import numpy as np


class PressurePosterior:
    def __init__(self, baseline, candidates, pressure, prior_mean, prior_std, noise_std,
                 *, noise_covariance=None):
        """Candidates are (point, component, load), or (point, load) for scalars.

        Noise covariance orders baseline rows before flattened candidate blocks.

        Scores use the planned baseline and candidate operators before the
        reference survey. fit/update use displacement increments from the same
        reference epoch, acquired after load transfer.
        """
        self.baseline = np.asarray(baseline, dtype=float)
        self.candidates = np.asarray(candidates, dtype=float)
        self.scalar_candidates = self.candidates.ndim == 2
        blocks = self.candidates[:, None, :] if self.scalar_candidates else self.candidates
        self.block_size = blocks.shape[1]
        self.pressure = np.asarray(pressure, dtype=float)
        self.mean = np.asarray(prior_mean, dtype=float)
        self.prior_cov = np.diag(np.asarray(prior_std, dtype=float)**2)
        self.noise_variance = float(noise_std)**2
        n_base, n_candidate = len(self.baseline), len(blocks)
        n_rows = n_base+n_candidate*self.block_size
        r = (self.noise_variance*np.eye(n_rows) if noise_covariance is None
             else np.asarray(noise_covariance, dtype=float))
        if r.shape != (n_rows, n_rows):
            raise ValueError("Noise covariance must cover baseline and candidate rows")
        r0 = r[:n_base, :n_base]
        weighted_baseline = np.linalg.solve(r0, self.baseline)
        self.noise_conditioning = np.linalg.solve(r0, r[:n_base, n_base:]).T.reshape(
            n_candidate, self.block_size, n_base)
        self.conditional_candidates = blocks-self.noise_conditioning @ self.baseline
        self.conditional_noise_covariance = np.array([
            r[n_base+i*self.block_size:n_base+(i+1)*self.block_size,
              n_base+i*self.block_size:n_base+(i+1)*self.block_size]
            -self.noise_conditioning[i] @ r[:n_base, n_base+i*self.block_size:n_base+(i+1)*self.block_size]
            for i in range(n_candidate)])
        precision = np.linalg.inv(self.prior_cov) + self.baseline.T @ weighted_baseline
        self.covariance = np.linalg.solve(precision, np.eye(len(self.mean)))
        self.gain = self.covariance @ weighted_baseline.T
        self.response = self.covariance @ self.conditional_candidates.transpose(0, 2, 1)
        self.innovation_covariance = self.conditional_noise_covariance + self.conditional_candidates @ self.response
        self.update_gain = np.linalg.solve(self.innovation_covariance,
                                          self.response.transpose(0, 2, 1)).transpose(0, 2, 1)
        self.scores = self.target_scores(self.pressure)
        self.selected = int(np.argmax(self.scores))

    def fit(self, baseline_readings):
        return self.mean + (np.asarray(baseline_readings)-self.baseline @ self.mean) @ self.gain.T

    def update(self, amplitudes, candidate, reading, *, baseline_readings=None):
        conditional_reading = np.asarray(reading)
        if self.scalar_candidates:
            conditional_reading = conditional_reading[..., None]
        if np.any(self.noise_conditioning[candidate]):
            if baseline_readings is None:
                raise ValueError("Correlated reading update requires the baseline readings")
            conditional_reading = conditional_reading-np.asarray(baseline_readings) @ self.noise_conditioning[candidate].T
        innovation = conditional_reading-np.asarray(amplitudes) @ self.conditional_candidates[candidate].T
        return amplitudes + innovation @ self.update_gain[candidate].T

    def updated_covariance(self, candidate):
        return self.covariance-self.update_gain[candidate] @ self.response[candidate].T

    def target_scores(self, target):
        target = np.asarray(target).reshape(-1, len(self.mean))
        response = target @ self.response
        gain = target @ self.update_gain
        return np.einsum("ijk,ijk->i", response, gain)/len(target)

    def pressure_sd(self, candidate=None):
        covariance = self.covariance if candidate is None else self.updated_covariance(candidate)
        return np.sqrt(np.einsum("ij,jk,ik->i", self.pressure, covariance, self.pressure))


def conformal_radius(standardized_errors, coverage):
    """Finite-sample split-conformal order statistic, with rows as cases."""
    scores = np.max(np.abs(standardized_errors), axis=1)
    rank = int(np.ceil((len(scores)+1)*coverage))
    if not 1 <= rank <= len(scores):
        raise ValueError("Calibration sample size cannot support the requested coverage")
    return float(np.partition(scores, rank-1)[rank-1])
