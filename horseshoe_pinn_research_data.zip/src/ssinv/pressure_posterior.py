"""Load-space inference on a physics-trained mixed neural response."""
from __future__ import annotations

import numpy as np


class PressurePosterior:
    def __init__(self, baseline, candidates, pressure, prior_mean, prior_std, noise_std,
                 *, noise_covariance=None):
        """Noise covariance orders baseline rows before all candidate rows.

        Each candidate is conditioned separately on the installed baseline.
        Unobserved candidate readings never enter inference.
        """
        self.baseline = np.asarray(baseline, dtype=float)
        self.candidates = np.asarray(candidates, dtype=float)
        self.pressure = np.asarray(pressure, dtype=float)
        self.mean = np.asarray(prior_mean, dtype=float)
        self.prior_cov = np.diag(np.asarray(prior_std, dtype=float)**2)
        self.noise_variance = float(noise_std)**2
        n_base, n_candidate = len(self.baseline), len(self.candidates)
        r = (self.noise_variance*np.eye(n_base+n_candidate) if noise_covariance is None
             else np.asarray(noise_covariance, dtype=float))
        if r.shape != (n_base+n_candidate, n_base+n_candidate):
            raise ValueError("Noise covariance must cover baseline and candidate rows")
        r0 = r[:n_base, :n_base]
        weighted_baseline = np.linalg.solve(r0, self.baseline)
        self.noise_conditioning = np.linalg.solve(r0, r[:n_base, n_base:]).T
        self.conditional_candidates = self.candidates-self.noise_conditioning @ self.baseline
        self.conditional_noise_variance = np.diag(r)[n_base:]-np.einsum(
            "ij,ij->i", self.noise_conditioning, r[n_base:, :n_base])
        precision = np.linalg.inv(self.prior_cov) + self.baseline.T @ weighted_baseline
        self.covariance = np.linalg.solve(precision, np.eye(len(self.mean)))
        self.gain = self.covariance @ weighted_baseline.T
        self.response = self.covariance @ self.conditional_candidates.T
        self.innovation_variance = self.conditional_noise_variance + np.einsum(
            "ij,ji->i", self.conditional_candidates, self.response)
        pressure_response = self.pressure @ self.response
        self.scores = np.mean(pressure_response**2, axis=0) / self.innovation_variance
        self.selected = int(np.argmax(self.scores))

    def fit(self, baseline_readings):
        return self.mean + (np.asarray(baseline_readings)-self.baseline @ self.mean) @ self.gain.T

    def update(self, amplitudes, candidate, reading, *, baseline_readings=None):
        conditional_reading = np.asarray(reading)
        if np.any(self.noise_conditioning[candidate]):
            if baseline_readings is None:
                raise ValueError("Correlated reading update requires the baseline readings")
            conditional_reading = conditional_reading-np.asarray(baseline_readings) @ self.noise_conditioning[candidate]
        innovation = conditional_reading-np.asarray(amplitudes) @ self.conditional_candidates[candidate]
        return amplitudes + innovation[..., None]*self.response[:, candidate]/self.innovation_variance[candidate]

    def updated_covariance(self, candidate):
        v = self.response[:, candidate]
        return self.covariance-np.outer(v, v)/self.innovation_variance[candidate]

    def pressure_sd(self, candidate=None):
        covariance = self.covariance if candidate is None else self.updated_covariance(candidate)
        return np.sqrt(np.einsum("ij,jk,ik->i", self.pressure, covariance, self.pressure))


def conformal_radius(standardized_errors, coverage):
    """Finite-sample split-conformal order statistic, with rows as cases."""
    scores = np.max(np.abs(standardized_errors), axis=1)
    rank = int(np.ceil((len(scores)+1)*coverage))
    if not 1 <= rank <= len(scores):
        raise ValueError("Calibration sample size cannot support the requested coverage")
    return float(np.partition(scores, rank-1)[rank-1])
