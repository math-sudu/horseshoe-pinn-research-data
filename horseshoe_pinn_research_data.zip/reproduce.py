"""Reproduce pressure inference and support demand from the numerical inputs."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

import numpy as np
from scipy.interpolate import BarycentricInterpolator
from scipy.special import ndtri
from scipy.stats import qmc
from threadpoolctl import threadpool_limits

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))

from ssinv.pressure_posterior import conformal_radius
from ssinv.response_mixture import ResponseMixture, expected_variance_reduction
from ssinv.section_recovery import section_resultants, thickness_weights
from ssinv.monitoring_targets import TARGETS, monitoring_projection, select_candidate


def read_json(name):
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def read_arrays(name):
    with np.load(ROOT / name, allow_pickle=False) as data:
        return {key: data[key] for key in data.files}


def write_json(path, data):
    path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")


def observation_map(fields):
    return np.concatenate((fields["baseline_xy_m"], fields["candidate_xy_m"])).reshape(-1, 4)


def joint_inputs():
    settings = read_json("config/joint.json")
    saved = read_arrays("data/joint_neural_family.npz")
    config = settings["response"]
    count = len(config["training_moduli_mpa"])
    lo, hi = np.log(config["stiffness_prior"]["bounds_mpa"])
    x, weights = np.polynomial.legendre.leggauss(config["stiffness_prior"]["quadrature_order"])
    log_e = (lo+hi)/2+(hi-lo)*x/2
    interpolate = BarycentricInterpolator(np.log(saved["moduli_mpa"][:count]), np.eye(count), axis=0)
    fields = {key: np.einsum("jk,k...->j...", interpolate(log_e), value[:count])
              for key, value in saved.items() if key not in ("moduli_mpa", "depth_m")}
    observations = np.stack([observation_map({key: value[k] for key, value in fields.items()})
                              for k in range(len(weights))])
    return settings, saved, fields, observations, weights/2


def joint(out):
    settings, anchors, fields, observations, weights = joint_inputs()
    prior = settings["prior"]
    report = read_json("data/joint_report.json")
    samples = read_arrays("data/joint_samples.npz")
    references = read_arrays("data/joint_reference.npz")
    stress_reference = read_arrays("data/joint_stress_reference.npz")
    nominal = int(np.flatnonzero(references["moduli_mpa"] == 1000)[0])
    truth0 = {key: value[nominal] for key, value in references.items()
              if key not in ("moduli_mpa", "depth_m")}
    nrows = observations.shape[1]
    covariance = prior["noise_std_m"]**2*np.eye(nrows)
    fixed_index = int(np.flatnonzero(anchors["moduli_mpa"] == 1000)[0])
    fixed_fields = {key: value[fixed_index:fixed_index+1] for key, value in anchors.items()
                    if key not in ("moduli_mpa", "depth_m")}
    fixed_obs = observation_map({key: value[0] for key, value in fixed_fields.items()})[None]

    def model(obs=observations, mass=weights, noise=covariance):
        return ResponseMixture(obs, mass, prior["prior_mean_mpa"], prior["prior_std_mpa"], noise)

    cal_loads, loads = samples["calibration_loads_mpa"], samples["test_loads_mpa"]
    cal_y = cal_loads @ observation_map(truth0).T+samples["calibration_noise_m"]
    cal_p = cal_loads @ truth0["pressure_mpa"].T
    records = []
    for k, modulus in enumerate(references["moduli_mpa"]):
        truth = {key: value[k] for key, value in references.items() if key not in ("moduli_mpa", "depth_m")}
        readings = loads @ observation_map(truth).T+samples["test_noise_m"]
        exact = loads @ truth["pressure_mpa"].T
        for case, selection in zip(settings["cases"], report["selections"], strict=True):
            stress_selection = next(s for s in report["target_designs"]["transition_stress"]["selections"]
                                    if s["layout"] == case["name"])
            record = dict(layout=case["name"], modulus_mpa=float(modulus), states={})
            states = [("baseline", case["baseline_rows"])]
            for name, candidate in [("selected", selection["selected_index"]),
                    ("stress_selected", stress_selection["selected_index"]),
                    ("fixed_design", next(i for i, p in enumerate(settings["layout"]["candidates"])
                                          if p["id"] == selection["fixed_response_selected_id"]))]:
                if name in ("selected", "stress_selected") or case["candidate_access"] == "full":
                    states.append((name, case["baseline_rows"]+[14+2*candidate, 15+2*candidate]))
            for method, response, target_fields in [("joint", model(), fields),
                    ("fixed", model(fixed_obs, [1.]), fixed_fields)]:
                for state, rows in states:
                    if method == "fixed" and state == "stress_selected":
                        continue
                    conditioned = response.condition(rows)
                    posterior = conditioned.fit(readings[:, rows])
                    prediction, variance = posterior.target_moments(target_fields["pressure_mpa"])
                    mse = np.mean((prediction-exact)**2, axis=1)
                    summary = dict(pressure_rmse_mpa=float(np.sqrt(mse.mean())),
                                   load_rmse_mpa=np.sqrt(np.mean((posterior.load_moments()[0]-loads)**2, axis=0)).tolist())
                    if state == "baseline":
                        baseline_mse = mse
                    else:
                        summary["pressure_mse_reduction"] = float(1-mse.mean()/baseline_mse.mean())
                        summary["pressure_deterioration_fraction"] = float(np.mean(mse > baseline_mse))
                    if method == "joint" and state in ("baseline", "selected"):
                        cal_mean, cal_var = conditioned.fit(cal_y[:, rows]).target_moments(target_fields["pressure_mpa"])
                        radius = conformal_radius((cal_mean-cal_p)/np.sqrt(cal_var), prior["calibration"]["coverage"])
                        summary.update(conformal_radius=radius,
                            simultaneous_coverage=float(np.mean(np.max(np.abs(prediction-exact)/np.sqrt(variance), axis=1) <= radius)),
                            mean_halfwidth_mpa=float(radius*np.sqrt(variance).mean()))
                    if method == "joint":
                        stress_truth = (stress_reference["reference_fine_stress_mpa"]
                                        if modulus == 1000 else truth["stress_mpa"])
                        summary.update(mechanical_outcome(posterior, fields, loads, stress_truth, anchors["depth_m"]))
                    record["states"][method+"_"+state] = summary
            records.append(record)
    projection = np.zeros((4,14));projection[0,1] = -1
    for i, chord in enumerate(settings["layout"]["baseline"][1:]):
        projection[i+1,2+4*i:4+4*i] = chord["direction"]
        projection[i+1,4+4*i:6+4*i] = -np.array(chord["direction"])
    projected = model(np.einsum("ir,krj->kij",projection,observations[:,:14]), weights,
                      projection @ covariance[:14,:14] @ projection.T)
    y = loads @ observation_map(truth0).T+samples["test_noise_m"]
    posterior = projected.condition(range(4)).fit(y[:,:14] @ projection.T)
    prediction = posterior.target_mean(fields["pressure_mpa"])
    projected_mse = float(np.mean((prediction-loads @ truth0["pressure_mpa"].T)**2))
    projected_mechanics = mechanical_outcome(posterior, fields, loads,
        stress_reference["reference_fine_stress_mpa"], anchors["depth_m"])
    noise_results = []
    c = np.tile(np.eye(2), (nrows//2,1))
    for selection in report["noise_design"]["selections"]:
        case = next(case for case in settings["cases"] if case["name"] == selection["layout"])
        spec, chosen = selection["noise"], selection["selected_index"]
        r = spec["independent_std_m"]**2*np.eye(nrows)+spec["datum_std_m"]**2*(c @ c.T)
        if spec["likelihood"] == "diagonal":
            r = np.diag(np.diag(r))
        response = model(noise=r)
        row = dict(layout=case["name"], noise=spec["name"], states={})
        for state, used in (("baseline",case["baseline_rows"]),
                            ("selected",case["baseline_rows"]+[14+2*chosen,15+2*chosen])):
            conditioned = response.condition(used)
            for split in ("calibration","test"):
                a = samples[split+"_loads_mpa"]
                error = samples[split+"_noise_m"]*spec["independent_std_m"]/prior["noise_std_m"]
                error += spec["datum_std_m"]*samples[split+"_datum_standard_normal"] @ c.T
                y = a @ observation_map(truth0).T+error
                prediction, variance = conditioned.fit(y[:,used]).target_moments(fields["pressure_mpa"])
                error_p = prediction-a @ truth0["pressure_mpa"].T
                if split == "calibration":
                    radius = conformal_radius(error_p/np.sqrt(variance), prior["calibration"]["coverage"])
                else:
                    row["states"][state] = dict(pressure_rmse_mpa=float(np.sqrt(np.mean(error_p**2))),
                        conformal_radius=radius,
                        simultaneous_coverage=float(np.mean(np.max(np.abs(error_p)/np.sqrt(variance),axis=1) <= radius)),
                        mean_halfwidth_mpa=float(radius*np.sqrt(variance).mean()))
        noise_results.append(row)
    write_json(out/"joint_summary.json", dict(results=records, projected_mse_mpa2=projected_mse,
                                             projected_mechanics=projected_mechanics,
                                             noise_results=noise_results))
    print(f"Reproduced {len(records)} paired joint/fixed conditions and {len(noise_results)} noise conditions.")


def mechanical_outcome(posterior, fields, loads, reference, depth):
    stress = posterior.target_mean(fields["stress_mpa"][:, :, :, 0])
    exact_stress = np.einsum("nl,sdl->nsd", loads, reference[:, :, 0])
    nm = posterior.target_mean(section_resultants(fields["stress_mpa"][:, :, :, 0], depth))
    exact_nm = np.einsum("nl,srl->nsr", loads, section_resultants(reference[:, :, 0], depth))
    mse = np.einsum("d,nsd->ns", thickness_weights(depth)/(depth[-1]-depth[0]),
                    (stress-exact_stress)**2)
    return dict(face_ct_rmse_mpa=np.sqrt(np.mean((stress-exact_stress)**2, axis=0))[:, [0, -1]].tolist(),
                profile_ct_rmse_mpa=np.sqrt(mse.mean(axis=0)).tolist(),
                transition_profile_rmse_mpa=float(np.sqrt(mse[:, 1:3].mean())),
                section_resultant_rmse=np.sqrt(np.mean((nm-exact_nm)**2, axis=0)).tolist())


def design(out, target_name):
    """Recompute prospective scores without opening independent reference fields."""
    settings, anchors, fields, observations, weights = joint_inputs()
    prior, spec = settings["prior"], settings["response"]["design"]
    layout, cases = settings["layout"], settings["cases"]
    points = [layout["baseline"][0]["xy_m"]]
    for chord in layout["baseline"][1:]:
        points.extend(chord["xy_m"])
    points.extend(p["xy_m"] for p in layout["candidates"])
    xy = np.asarray(points)
    partners = np.linalg.norm(xy[:,None]-xy[None]*[-1,1],axis=-1).argmin(axis=1)
    mirror_rows = (2*partners[:,None]+np.arange(2)).ravel()
    signs = np.tile([-1.,1.],len(points))
    target = monitoring_projection(fields, anchors["depth_m"], target_name)
    records = []
    noise_cases = [dict(name="independent_0.1mm",independent_std_m=prior["noise_std_m"],
                       datum_std_m=0.,likelihood="full")]
    if target_name == "pressure":
        noise_cases += settings["noise"]["cases"]
    for noise in noise_cases:
        c = np.tile(np.eye(2),(len(points),1))
        covariance = noise["independent_std_m"]**2*np.eye(len(mirror_rows))+noise["datum_std_m"]**2*(c @ c.T)
        if noise["likelihood"]=="diagonal":
            covariance = np.diag(np.diag(covariance))
        response = ResponseMixture(observations,weights,prior["prior_mean_mpa"],prior["prior_std_mpa"],covariance)
        baselines = {case["baseline"]:case["baseline_rows"] for case in cases}
        scores = {key:[] for key in baselines}
        risks = {key:[] for key in baselines}
        for scramble in range(spec["scrambles"]):
            u = qmc.Sobol(5+len(mirror_rows),scramble=True,seed=spec["seed"]+scramble).random_base2(spec["sobol_power"])
            node = np.searchsorted(np.cumsum(weights),u[:,0]);z=ndtri(u[:,1:])
            loads = np.array(prior["prior_mean_mpa"])+z[:,:4]*prior["prior_std_mpa"]
            y = np.einsum("nrl,nl->nr",observations[node],loads)+z[:,4:] @ np.linalg.cholesky(covariance).T
            y = np.vstack((y,y[:,mirror_rows]*signs))
            for name,rows in baselines.items():
                base = response.condition(rows).fit(y[:,rows])
                risks[name].append(float(base.target_moments(target)[1].sum(axis=1).mean()))
                batch = np.zeros(len(layout["candidates"]))
                for i in range(len(batch)):
                    extra = [14+2*i,15+2*i]
                    if set(rows).intersection(extra):
                        continue
                    used = rows+extra
                    augmented = response.condition(used).fit(y[:,used])
                    batch[i] = expected_variance_reduction(base,augmented,target).mean()
                scores[name].append(batch)
        average = {k:np.mean(v,axis=0) for k,v in scores.items()}
        selections = []
        for case in cases:
            chosen, equivalent = select_candidate(average[case["baseline"]], case["allowed_indices"])
            selections.append(dict(layout=case["name"], selected_index=chosen,
                selected_id=layout["candidates"][chosen]["id"],
                equivalent_ids=[layout["candidates"][i]["id"] for i in equivalent],
                expected_baseline_variance_mpa2=float(np.mean(risks[case["baseline"]]))))
        records.append(dict(target=target_name, definition=TARGETS[target_name], noise=noise["name"],
                            scores={k:v.tolist() for k,v in average.items()}, selections=selections))
        print("Recomputed design:",noise["name"],flush=True)
    write_json(out/f"{target_name}_design_scores.json",records)


def uniform(out, feature_seed):
    settings = read_json("config/uniform.json")
    seeds = settings["feature_seeds"] if feature_seed is None else [feature_seed]
    for seed in seeds:
        seed_out = out / f"seed{seed}"
        seed_out.mkdir(parents=True, exist_ok=True)
        response = read_arrays(f"data/uniform_seed{seed}.npz")
        scores = np.mean(response["pressure_mpa_added"]**2, axis=0) / (1 + response["leverage"])
        tied = np.flatnonzero(scores >= scores.max() * (1 - settings["selection"]["tie_relative"]))
        selected = int(tied[0])
        write_json(seed_out / "selection.json", {
            "candidate_number": selected + 1,
            "pressure_scores_mpa2": scores.tolist(),
            "leverage": response["leverage"].tolist(),
        })
        reference = read_arrays("data/uniform_reference.npz")
        rows, arrays = [], {}
        for noise_seed in [0] + settings["observations"]["noise_seeds"]:
            rng = np.random.default_rng(noise_seed)
            noise = np.zeros(28) if noise_seed == 0 else rng.normal(
                0.0, settings["observations"]["noise_std_m"], 28)
            baseline = reference["baseline_m"] + noise[:4]
            readings = reference["candidates_m"] + noise[4:]
            base = {key: response[f"{key}_baseline"] @ baseline for key in
                    ("pressure_mpa", "inner_u_m", "baseline_prediction_m", "candidate_prediction_m", "loads_mpa")}
            for candidate in range(-1, len(readings)):
                fields = {key: value.copy() for key, value in base.items()}
                if candidate >= 0:
                    innovation = (readings[candidate] - base["candidate_prediction_m"][candidate]) / settings["observations"]["data_scale_m"]
                    multiplier = innovation / (1 + response["leverage"][candidate])
                    for key in fields:
                        fields[key] += multiplier * response[f"{key}_added"][:, candidate]
                fields["inner_u_m"] = fields["inner_u_m"].reshape(-1, 2)
                residuals = fields["baseline_prediction_m"] - baseline
                if candidate >= 0:
                    residuals = np.r_[residuals, fields["candidate_prediction_m"][candidate] - readings[candidate]]
                result = {
                    "contact_relative_l2": float(np.linalg.norm(fields["pressure_mpa"] - reference["pressure_mpa"]) / np.linalg.norm(reference["pressure_mpa"])),
                    "displacement_relative_l2": float(np.linalg.norm(fields["inner_u_m"] - reference["inner_u_m"]) / np.linalg.norm(reference["inner_u_m"])),
                    "Qx_mpa": float(fields["loads_mpa"][0]),
                    "Qy_mpa": float(fields["loads_mpa"][1]),
                    "observation_rms_m": float(np.sqrt(np.mean(residuals**2))),
                }
                rows.append({"feature_seed": seed, "noise_seed": noise_seed,
                             "candidate_number": candidate + 1,
                             "selected": candidate == selected, **result})
                for key, value in fields.items():
                    arrays.setdefault(key, []).append(value)
        write_json(seed_out / "metrics.json", rows)
        np.savez_compressed(seed_out / "predicted_fields.npz",
                            **{key: np.asarray(value) for key, value in arrays.items()})
        print(f"Feature seed {seed}: {len(rows)} cases; selected N{selected + 1:02d}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("study", choices=("joint", "design", "uniform"))
    parser.add_argument("--feature-seed", type=int, choices=(71, 1071, 2071))
    parser.add_argument("--target", choices=TARGETS, default="pressure")
    parser.add_argument("--out", type=Path, default=ROOT / "results")
    args = parser.parse_args()
    out = args.out / args.study
    out.mkdir(parents=True, exist_ok=True)
    with threadpool_limits(limits=2):
        if args.study == "joint":
            joint(out)
        elif args.study == "design":
            design(out, args.target)
        else:
            uniform(out, args.feature_seed)


if __name__ == "__main__":
    main()
