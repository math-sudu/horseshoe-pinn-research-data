"""Reproduce pressure inference from the supplied numerical inputs."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

import numpy as np
from threadpoolctl import threadpool_limits

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))

from ssinv.pressure_posterior import PressurePosterior, conformal_radius


def read_json(name):
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def read_arrays(name):
    with np.load(ROOT / name, allow_pickle=False) as data:
        return {key: data[key] for key in data.files}


def write_json(path, data):
    path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")


def sample_ensemble(settings, split):
    rng = np.random.default_rng(settings[split]["seed"])
    count = settings[split]["samples"]
    loads = rng.normal(settings["prior_mean_mpa"], settings["prior_std_mpa"], (count, 4))
    noise = rng.normal(0.0, settings["noise_std_m"], (count, 28))
    return loads, noise


def four_mode(out):
    settings = read_json("config/inference.json")
    neural = read_arrays("data/neural_responses.npz")
    baseline = neural["baseline_m"].copy()
    baseline[:, settings["baseline_null_columns"]] = 0.0
    model = PressurePosterior(baseline, neural["candidates_m"], neural["pressure_mpa"],
                              settings["prior_mean_mpa"], settings["prior_std_mpa"],
                              settings["noise_std_m"])
    selected = model.selected
    # Acquisition depends only on the neural response, load prior and noise model.
    write_json(out / "selection.json", {
        "candidate_number": selected + 1,
        "pressure_scores_mpa2": model.scores.tolist(),
    })
    reference = read_arrays("data/reference_responses.npz")
    errors, arrays = {}, {}
    for split in ("calibration", "test"):
        loads, noise = sample_ensemble(settings, split)
        observations = loads @ reference["baseline_m"].T + noise[:, :4]
        readings = loads @ reference["candidates_m"].T + noise[:, 4:]
        truth = loads @ reference["pressure_mpa"].T
        fitted = model.fit(observations)
        updated = model.update(fitted, selected, readings[:, selected])
        errors[split] = (fitted @ model.pressure.T - truth, updated @ model.pressure.T - truth)
        arrays.update({f"{split}_loads_mpa": loads, f"{split}_noise_m": noise,
                       f"{split}_baseline_load_estimates_mpa": fitted,
                       f"{split}_selected_load_estimates_mpa": updated})
    states = []
    for index, candidate in enumerate((None, selected)):
        sd = model.pressure_sd(candidate)
        radius = conformal_radius(errors["calibration"][index] / sd,
                                  settings["calibration"]["coverage"])
        test_error = errors["test"][index]
        estimates = arrays[f"test_{'baseline' if index == 0 else 'selected'}_load_estimates_mpa"]
        states.append({
            "name": "baseline" if candidate is None else f"N{candidate + 1:02d}",
            "pressure_test_rmse_mpa": float(np.sqrt(np.mean(test_error**2))),
            "conformal_radius": radius,
            "simultaneous_test_coverage": float(np.mean(np.max(np.abs(test_error) / sd, axis=1) <= radius)),
            "mean_band_halfwidth_mpa": float(np.mean(radius * sd)),
            "load_test_rmse_mpa": np.sqrt(np.mean((estimates - arrays["test_loads_mpa"])**2, axis=0)).tolist(),
        })
        arrays[f"{'baseline' if index == 0 else 'selected'}_pressure_sd_mpa"] = sd
    summary = {
        "selected_id": f"N{selected + 1:02d}",
        "states": states,
        "mean_squared_pressure_error_reduction": float(1 - np.mean(errors["test"][1]**2) / np.mean(errors["test"][0]**2)),
    }
    np.savez_compressed(out / "pressure_ensemble.npz", **arrays)
    write_json(out / "pressure_summary.json", summary)
    print(json.dumps(summary, indent=2))


def uniform(out, feature_seed):
    settings = read_json("config/uniform.json")
    seeds = settings["feature_seeds"] if feature_seed is None else [feature_seed]
    for seed in seeds:
        seed_out = out / f"seed{seed}"
        seed_out.mkdir(parents=True, exist_ok=True)
        response = read_arrays(f"data/uniform_seed{seed}.npz")
        scores = np.mean(response["pressure_mpa_added"]**2, axis=0) / (1 + response["leverage"])
        tied = np.flatnonzero(scores >= scores.max() * (1 - settings["selection"]["tie_relative"]))
        selected = int(tied[0])
        write_json(seed_out / "selection.json", {
            "candidate_number": selected + 1,
            "pressure_scores_mpa2": scores.tolist(),
            "leverage": response["leverage"].tolist(),
        })
        reference = read_arrays("data/uniform_reference.npz")
        rows, arrays = [], {}
        for noise_seed in [0] + settings["observations"]["noise_seeds"]:
            rng = np.random.default_rng(noise_seed)
            noise = np.zeros(28) if noise_seed == 0 else rng.normal(
                0.0, settings["observations"]["noise_std_m"], 28)
            baseline = reference["baseline_m"] + noise[:4]
            readings = reference["candidates_m"] + noise[4:]
            base = {key: response[f"{key}_baseline"] @ baseline for key in
                    ("pressure_mpa", "inner_u_m", "baseline_prediction_m", "candidate_prediction_m", "loads_mpa")}
            for candidate in range(-1, len(readings)):
                fields = {key: value.copy() for key, value in base.items()}
                if candidate >= 0:
                    innovation = (readings[candidate] - base["candidate_prediction_m"][candidate]) / settings["observations"]["data_scale_m"]
                    multiplier = innovation / (1 + response["leverage"][candidate])
                    for key in fields:
                        fields[key] += multiplier * response[f"{key}_added"][:, candidate]
                fields["inner_u_m"] = fields["inner_u_m"].reshape(-1, 2)
                residuals = fields["baseline_prediction_m"] - baseline
                if candidate >= 0:
                    residuals = np.r_[residuals, fields["candidate_prediction_m"][candidate] - readings[candidate]]
                result = {
                    "contact_relative_l2": float(np.linalg.norm(fields["pressure_mpa"] - reference["pressure_mpa"]) / np.linalg.norm(reference["pressure_mpa"])),
                    "displacement_relative_l2": float(np.linalg.norm(fields["inner_u_m"] - reference["inner_u_m"]) / np.linalg.norm(reference["inner_u_m"])),
                    "Qx_mpa": float(fields["loads_mpa"][0]),
                    "Qy_mpa": float(fields["loads_mpa"][1]),
                    "observation_rms_m": float(np.sqrt(np.mean(residuals**2))),
                }
                rows.append({"feature_seed": seed, "noise_seed": noise_seed,
                             "candidate_number": candidate + 1,
                             "selected": candidate == selected, **result})
                for key, value in fields.items():
                    arrays.setdefault(key, []).append(value)
        write_json(seed_out / "metrics.json", rows)
        np.savez_compressed(seed_out / "predicted_fields.npz",
                            **{key: np.asarray(value) for key, value in arrays.items()})
        print(f"Feature seed {seed}: {len(rows)} cases; selected N{selected + 1:02d}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("study", choices=("four-mode", "uniform"))
    parser.add_argument("--feature-seed", type=int, choices=(71, 1071, 2071))
    parser.add_argument("--out", type=Path, default=ROOT / "results")
    args = parser.parse_args()
    out = args.out / args.study
    out.mkdir(parents=True, exist_ok=True)
    with threadpool_limits(limits=2):
        if args.study == "four-mode":
            four_mode(out)
        else:
            uniform(out, args.feature_seed)


if __name__ == "__main__":
    main()
